import 'package:flutter/material.dart';
import 'dbs_helper.dart';

class MarksListScreen extends StatefulWidget {
  @override
  _MarksListScreenState createState() => _MarksListScreenState();
}

class _MarksListScreenState extends State<MarksListScreen> {
  List<Map<String, dynamic>> marksList = [];

  @override
  void initState() {
    super.initState();
    fetchMarks();
  }

  // Fetch marks from database
  void fetchMarks() async {
    final data = await DBHelper.getMarks();
    setState(() {
      marksList = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('All Subject Marks')),
      body: marksList.isEmpty
          ? Center(child: Text('No records found'))
          : ListView.builder(
        itemCount: marksList.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(vertical: 6, horizontal: 16),
            child: ListTile(
              leading: CircleAvatar(
                child: Text(marksList[index]['marks'].toString()),
              ),
              title: Text(marksList[index]['subject']),
              subtitle: Text('Marks: ${marksList[index]['marks']}'),
            ),
          );
        },
      ),
    );
  }
}
