import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'user_model.dart';

class UserService {
  // یوزرز کو محفوظ کرنے کا طریقہ
  Future<void> saveUsers(List<User> users) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> userList = users.map((user) => jsonEncode(user.toMap())).toList();
    await prefs.setStringList('users', userList);
  }

  // یوزرز کو حاصل کرنے کا طریقہ
  Future<List<User>> loadUsers() async {
    final prefs = await SharedPreferences.getInstance();
    List<String>? userList = prefs.getStringList('users');
    if (userList != null) {
      return userList.map((user) => User.fromMap(jsonDecode(user))).toList();
    }
    return [];
  }
}
