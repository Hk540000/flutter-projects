import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DBHelper {
  static Database? _database;
  static const String marksTable = 'marks';

  // Get Database
  static Future<Database> getDatabase() async {
    if (_database != null) return _database!;

    String path = join(await getDatabasesPath(), 'marks_database.db');
    print("Database Path: $path"); // Debugging

    _database = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute(
          'CREATE TABLE $marksTable (id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT, marks INTEGER)',
        );
      },
    );
    return _database!;
  }

  // Insert Marks
  static Future<void> insertMarks(String subject, int marks) async {
    final db = await getDatabase();
    int result = await db.insert(marksTable, {'subject': subject, 'marks': marks});
    print("Inserted Marks: $result"); // Debugging
  }

  // Get Marks
  static Future<List<Map<String, dynamic>>> getMarks() async {
    final db = await getDatabase();
    List<Map<String, dynamic>> result = await db.query(marksTable);
    print("Fetched Marks: $result"); // Debugging
    return result;
  }
}
