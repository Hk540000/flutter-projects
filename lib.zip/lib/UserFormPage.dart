import 'package:flutter/material.dart';
import 'user.dart' as user_model;
import 'user_preferences.dart' as user_prefs;
import 'UserDisplayPage.dart';

class UserFormPage extends StatefulWidget {
  @override
  _UserFormPageState createState() => _UserFormPageState();
}

class _UserFormPageState extends State<UserFormPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  String? _status = 'Inactive';

  Future<void> _saveData() async {
    user_model.User newUser = user_model.User(
      email: _emailController.text,
      phone: _phoneController.text,
      status: _status ?? 'Inactive',
    );

    List<user_model.User> users = await user_prefs.UserPreferences.getUsers();
    users.add(newUser);
    await user_prefs.UserPreferences.saveUsers(users);

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => UserDisplayPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("User Form")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: "Email"),
            ),
            TextField(
              controller: _phoneController,
              decoration: InputDecoration(labelText: "Phone Number"),
              keyboardType: TextInputType.phone,
            ),
            Row(
              children: [
                Text("Status: "),
                Radio(
                  value: "Active",
                  groupValue: _status,
                  onChanged: (value) {
                    setState(() {
                      _status = value.toString();
                    });
                  },
                ),
                Text("Active"),
                Radio(
                  value: "Inactive",
                  groupValue: _status,
                  onChanged: (value) {
                    setState(() {
                      _status = value.toString();
                    });
                  },
                ),
                Text("Inactive"),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveData,
              child: Text("Submit"),
            ),
          ],
        ),
      ),
    );
  }
}
