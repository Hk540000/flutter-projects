class User {
  String email;
  String password;
  String gender;
  String address;

  User({
    required this.email,
    required this.password,
    required this.gender,
    required this.address,
  });

  // یوزر کو Map میں تبدیل کرنے کا طریقہ
  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'password': password,
      'gender': gender,
      'address': address,
    };
  }

  // Map سے یوزر بنانے کا طریقہ
  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      email: map['email'],
      password: map['password'],
      gender: map['gender'],
      address: map['address'],
    );
  }
}
