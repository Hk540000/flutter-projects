import 'package:flutter/material.dart';
import 'user.dart' as user_model;
import 'user_preferences.dart' as user_prefs;

class UserDisplayPage extends StatefulWidget {
  @override
  _UserDisplayPageState createState() => _UserDisplayPageState();
}

class _UserDisplayPageState extends State<UserDisplayPage> {
  List<user_model.User> _users = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    List<user_model.User> users = await user_prefs.UserPreferences.getUsers();
    setState(() {
      _users = users;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("User Information"),
        backgroundColor: Colors.lightBlue,
      ),
      body: ListView.builder(
        itemCount: _users.length,
        itemBuilder: (context, index) {
          user_model.User user = _users[index];
          return Card(
            elevation: 8,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            margin: EdgeInsets.all(16),
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.person,
                    size: 80,
                    color: Colors.lightBlue,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Email: ${user.email}',
                    style: TextStyle(fontSize: 18),
                  ),
                  Text(
                    'Phone: ${user.phone}',
                    style: TextStyle(fontSize: 18),
                  ),
                  Text(
                    'Status: ${user.status}',
                    style: TextStyle(fontSize: 18),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
