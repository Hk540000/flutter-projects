import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: GradebookPage(),
    );
  }
}

class GradebookPage extends StatefulWidget {
  @override
  _GradebookPageState createState() => _GradebookPageState();
}

class _GradebookPageState extends State<GradebookPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _subjectController = TextEditingController();
  final TextEditingController _marksController = TextEditingController();
  List<Map<String, dynamic>> _grades = [];

  String calculateGrade(int marks) {
    if (marks >= 85) return 'A+';
    if (marks >= 80) return 'A';
    if (marks >= 65) return 'B';
    if (marks >= 51) return 'C';
    if (marks == 50) return 'D';
    return 'F';
  }

  void _addGrade() {
    final name = _nameController.text;
    final subject = _subjectController.text;
    final marksText = _marksController.text;

    if (name.isEmpty || subject.isEmpty || marksText.isEmpty) return;
    final marks = int.tryParse(marksText);
    if (marks == null || marks < 0 || marks > 100) return;

    setState(() {
      _grades.add({
        'name': name,
        'subject': subject,
        'marks': marks,
        'grade': calculateGrade(marks),
      });
    });

    _nameController.clear();
    _subjectController.clear();
    _marksController.clear();
  }

  void _deleteGrade(int index) {
    setState(() {
      _grades.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gradebook'),
        backgroundColor: Colors.lightBlue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Student Name'),
            ),
            TextField(
              controller: _subjectController,
              decoration: InputDecoration(labelText: 'Subject Name'),
            ),
            TextField(
              controller: _marksController,
              decoration: InputDecoration(labelText: 'Marks'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _addGrade,
              child: Text('Submit'),
            ),
            SizedBox(height: 20),

            // Table Format
            if (_grades.isNotEmpty)
              Table(
                border: TableBorder.all(color: Colors.black),
                columnWidths: {
                  0: FlexColumnWidth(2),
                  1: FlexColumnWidth(2),
                  2: FlexColumnWidth(1),
                  3: FlexColumnWidth(1),
                  4: FlexColumnWidth(1),
                },
                children: [
                  TableRow(
                    decoration: BoxDecoration(color: Colors.blue[200]),
                    children: [
                      tableCell('Student Name', isHeader: true),
                      tableCell('Subject', isHeader: true),
                      tableCell('Marks', isHeader: true),
                      tableCell('Grade', isHeader: true),
                      tableCell('Actions', isHeader: true),
                    ],
                  ),
                  ..._grades.asMap().entries.map((entry) {
                    final index = entry.key;
                    final grade = entry.value;
                    return TableRow(
                      children: [
                        tableCell(grade['name']),
                        tableCell(grade['subject']),
                        tableCell(grade['marks'].toString()),
                        tableCell(grade['grade']),
                        TableCell(
                          child: IconButton(
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _deleteGrade(index),
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget tableCell(String text, {bool isHeader = false}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontWeight: isHeader ? FontWeight.bold : FontWeight.normal,
          fontSize: isHeader ? 16 : 14,
        ),
      ),
    );
  }
}
