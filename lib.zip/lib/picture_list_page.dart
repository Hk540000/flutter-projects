import 'package:flutter/material.dart';

class PictureListPage extends StatelessWidget {
  final List<String> imagePaths = [
    'assets/pic1.png',
    'assets/pic2.png',
    'assets/pic3.png',
    'assets/pic4.png',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Picture List'),
        backgroundColor: Colors.lightBlue,
      ),
      body: ListView.builder(
        itemCount: imagePaths.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(7),
              ),
              child: Padding(
                padding: const EdgeInsets.all(6.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(7),
                      child: Image.asset(
                        imagePaths[index],
                        height: 240, // Increased height for better visibility
                        width: double.infinity,
                        fit: BoxFit.contain, // Ensures full image visibility
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Image ${index + 1}',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
