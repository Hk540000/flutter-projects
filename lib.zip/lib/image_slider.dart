import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ImageSliderScreen(),
    );
  }
}

class ImageSliderScreen extends StatelessWidget {
  final List<String> imageUrls = [
    'assets/pic1.png',
    'assets/pic2.png',
    'assets/pic3.png',
    'assets/pic4.png',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Image Slider")),
      body: Column(
        children: [
          SizedBox(height: 25),
          CarouselSlider(
            options: CarouselOptions(
              height: 450.0, // Adjusted height for better visibility
              autoPlay: true,
              enlargeCenterPage: true,
              aspectRatio: 16 / 9,
              viewportFraction: 0.8,
            ),
            items: imageUrls.map((url) {
              return Container(
                margin: EdgeInsets.all(5.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: Image.asset(
                    url,
                    fit: BoxFit.contain, // Ensures the full image is displayed
                    width: double.infinity,
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
