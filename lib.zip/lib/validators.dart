import 'package:email_validator/email_validator.dart';

class Validators {
  static String? validateEmail(String? value) {
    if (!EmailValidator.validate(value!)) {
      return "Enter a valid email";
    }
    return null;
  }

  static String? validatePassword(String? value) {
    if (!RegExp(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$').hasMatch(value!)) {
      return "Password must contain upper, lower, number, special char";
    }
    return null;
  }

  static String? validateAddress(String? value) {
    if (value!.length < 10) {
      return "Address must be at least 10 characters";
    }
    return null;
  }
}
