import 'package:flutter/material.dart';
import 'dbs_helper.dart';
import 'marks_list.dart';

class MarksFormScreen extends StatefulWidget {
  @override
  _MarksFormScreenState createState() => _MarksFormScreenState();
}

class _MarksFormScreenState extends State<MarksFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController subjectController = TextEditingController();
  final TextEditingController marksController = TextEditingController();
  List<Map<String, dynamic>> marksList = [];

  @override
  void initState() {
    super.initState();
    fetchMarks();
  }

  // Fetch marks from database
  void fetchMarks() async {
    final data = await DBHelper.getMarks();
    setState(() {
      marksList = data;
    });
  }

  // Calculate Grade & GPA
  Map<String, dynamic> calculateGradeAndGPA(int marks) {
    String grade;
    double gpa;

    if (marks < 50) {
      grade = "Fail";
      gpa = 2.0;
    } else if (marks >= 50 && marks < 65) {
      grade = "C";
      gpa = 2.0 + ((marks - 50) * 0.012);
    } else if (marks >= 65 && marks < 80) {
      grade = "B";
      gpa = 3.0 + ((marks - 65) * 0.067);
    } else {
      grade = "A";
      gpa = 4.0;
    }

    return {"grade": grade, "gpa": gpa.toStringAsFixed(2)};
  }

  // Insert marks into database
  void addMarks() async {
    if (_formKey.currentState!.validate()) {
      final subject = subjectController.text.trim();
      final marks = int.tryParse(marksController.text.trim()) ?? 0;

      var result = calculateGradeAndGPA(marks);

      await DBHelper.insertMarks(subject, marks);
      subjectController.clear();
      marksController.clear();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Marks added successfully!')),
      );

      fetchMarks(); // Refresh marks list
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Enter Subject Marks')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: subjectController,
                    decoration: InputDecoration(
                      labelText: 'Subject Name',
                      prefixIcon: Icon(Icons.book),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a subject name';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 12),
                  TextFormField(
                    controller: marksController,
                    decoration: InputDecoration(
                      labelText: 'Marks',
                      prefixIcon: Icon(Icons.score),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter marks';
                      } else if (int.tryParse(value) == null) {
                        return 'Enter valid marks';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: addMarks,
                      child: Text('Submit'),
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),

            marksList.isNotEmpty
                ? Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columnSpacing: 20,
                  columns: [
                    DataColumn(label: Text('Subject')),
                    DataColumn(label: Text('Marks')),
                    DataColumn(label: Text('Grade')),
                    DataColumn(label: Text('GPA')),
                  ],
                  rows: marksList.map((mark) {
                    var result = calculateGradeAndGPA(mark['marks']);
                    return DataRow(cells: [
                      DataCell(Text(mark['subject'])),
                      DataCell(Text(mark['marks'].toString())),
                      DataCell(Text(result['grade'])),
                      DataCell(Text(result['gpa'])),
                    ]);
                  }).toList(),
                ),
              ),
            )
                : Center(child: Text('No records found', style: TextStyle(fontSize: 16))),

            SizedBox(height: 16),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => MarksListScreen()),
                  );
                },
                child: Text('View Marks List'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 14),
                  backgroundColor: Colors.green,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
