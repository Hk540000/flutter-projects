// lib/user_preferences.dart

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'user.dart';

class UserPreferences {
  static const String _userListKey = 'userList';

  // یوزرز کی فہرست محفوظ کریں
  static Future<void> saveUsers(List<User> users) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> userJsonList =
    users.map((user) => jsonEncode(user.toJson())).toList();
    await prefs.setStringList(_userListKey, userJsonList);
  }

  //
  static Future<List<User>> getUsers() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? userJsonList = prefs.getStringList(_userListKey);
    if (userJsonList == null) return [];
    return userJsonList
        .map((userJson) => User.fromJson(jsonDecode(userJson)))
        .toList();
  }
}
