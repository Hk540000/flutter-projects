import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: NotificationScreen(),
    );
  }
}

class NotificationScreen extends StatefulWidget {
  @override
  _NotificationScreenState createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  List<String> messages = [];

  @override
  void initState() {
    super.initState();
    _showNotifications();
  }

  void _showNotifications() {
    List<String> newMessages = [
      "😊 Welcome!",
      "🌞 How is your day going?",
      "🔔 You have a new notification!",
      "⚙️ Your settings have been updated."
    ];

    Future.delayed(Duration(seconds: 1), () {
      setState(() {
        messages = newMessages;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: Text("Array Notification App"),
        backgroundColor: Colors.deepPurple,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16.0),
        itemCount: messages.length,
        itemBuilder: (context, index) {
          return Card(
            color: Colors.white,
            elevation: 6,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
            margin: EdgeInsets.symmetric(vertical: 8.0),
            child: ListTile(
              leading: Icon(Icons.notifications, color: Colors.deepPurple),
              title: Text(
                messages[index],
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
            ),
          );
        },
      ),
    );
  }
}
