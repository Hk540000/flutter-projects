import 'package:flutter/material.dart';
import 'user_model.dart';
import 'login_page.dart';
import 'bar.dart'; // ✅ bar.dart امپورٹ کریں

class ProfilePage extends StatelessWidget {
  final List<User> users;

  ProfilePage({required this.users});

  void _logout(BuildContext context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage()),
    );
  }

  void _navigateToHome(BuildContext context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => HomeScreen()), // ✅ HomeScreen پر نیویگیٹ کریں
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[100],
      appBar: AppBar(
        title: Text(
          'User Profiles',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blueGrey[700],
        actions: [
          IconButton(
            icon: Icon(Icons.home, color: Colors.white),
            onPressed: () => _navigateToHome(context), // ✅ نیویگیشن کو اپڈیٹ کریں
          ),
          IconButton(
            icon: Icon(Icons.logout, color: Colors.white),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(10.0),
        child: ListView.builder(
          itemCount: users.length,
          itemBuilder: (context, index) {
            final user = users[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              elevation: 5,
              color: Colors.white,
              margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundImage: AssetImage('assets/profile_placeholder.png'),
                ),
                title: Text(
                  user.email,
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blueGrey[800]),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 4.0),
                    Text('Gender: ${user.gender}', style: TextStyle(color: Colors.black87)),
                    Text('Address: ${user.address}', style: TextStyle(color: Colors.black87)),
                  ],
                ),
                contentPadding: EdgeInsets.all(16.0),
              ),
            );
          },
        ),
      ),
    );
  }
}
