import 'dart:math';
import 'package:flutter/material.dart';

class PictureTransitionPage extends StatefulWidget {
  @override
  _PictureTransitionPageState createState() => _PictureTransitionPageState();
}

class _PictureTransitionPageState extends State<PictureTransitionPage> {
  int _currentImageIndex = 0;

  final List<String> images = [
    'assets/pic1.png',
    'assets/hk1.jpg',
    'assets/hk2.jpg',
    'assets/pic4.png',
  ];

  void _nextImage() {
    setState(() {
      _currentImageIndex = (_currentImageIndex + 1) % images.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Picture Transition")),
      body: Center(
        child: GestureDetector(
          onTap: _nextImage, // Change image on tap
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Rotating Background Image
              Transform.rotate(
                angle: pi / 6, // Rotate by 30 degrees
                child: Image.asset(
                  images[(_currentImageIndex + 1) % images.length], // Next image as background
                  width: 300,
                  height: 300,
                  fit: BoxFit.cover,
                ),
              ),

              // Foreground Image (Active Image)
              Image.asset(
                images[_currentImageIndex],
                width: 250,
                height: 250,
                fit: BoxFit.cover,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
