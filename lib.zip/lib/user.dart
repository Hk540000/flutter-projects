// lib/user.dart

import 'dart:convert';

class User {
  final String email;
  final String phone;
  final String status;

  User({
    required this.email,
    required this.phone,
    required this.status,
  });

  // JSON میں تبدیل کریں
  Map<String, dynamic> toJson() => {
    'email': email,
    'phone': phone,
    'status': status,
  };

  // JSON سے User آبجیکٹ بنائیں
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
    );
  }
}
