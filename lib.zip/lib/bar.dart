import 'package:flutter/material.dart';
import 'package:projectand/picture_transition_page.dart';
import './gradebook_page.dart';
import './calculator_page.dart';
import './name_page.dart';
import './message_page.dart';
import './submit_page.dart';
import './UserFormPage.dart'; // ✅ Import User Form Page
import './UserDisplayPage.dart'; // ✅ Import User Display Page
import 'login_page.dart';
import 'new_page.dart';
import 'picture_list_page.dart';
import 'image_slider.dart';
import 'picture_list_page.dart';
import 'image_picker_screen.dart';
import 'notification_screen.dart';
import 'user_form.dart';
import 'user_list.dart';
import 'marks_form.dart';
import 'marks_list.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue,
        title: Row(
          children: [
            Image.asset('assets/logo.png', height: 40),
            SizedBox(width: 10),
            Text('Baba Guru Nanak University'),
            Spacer(),
            IconButton(icon: Icon(Icons.school), onPressed: () {}),
            IconButton(
              icon: Icon(Icons.logout),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()), // Apna Login Page yahan set karein
                );
              },
            ),  ],
        ),
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.lightBlue),
              child: Text(
                'BGNU Navigation',
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
            ),
            ListTile(
              leading: Icon(Icons.image),
              title: Text('Picture List'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PictureListPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.image),
              title: Text('Manage Users'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserFormScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.image),
              title: Text('Userlist'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.notifications),
              title: Text("Array"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => NotificationScreen()),
                );
              },
            ),



            ListTile(
              leading: Icon(Icons.photo_library),
              title: Text('Gallery'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ImagePickerScreen()),
                );
              },
            ),



            ListTile(
              leading: Icon(Icons.image),
              title: Text('Transition Page'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PictureTransitionPage()),
                );
              },
            ),

            ListTile(
              leading: Icon(Icons.photo_library),
              title: Text('Image Slider'), // ✅ Added Image Slider Option
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ImageSliderScreen()),
                );
              },
            ),

            ListTile(
              leading: Icon(Icons.book),
              title: Text('Gradebook'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => GradebookPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.calculate),
              title: Text('Calculator'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CalculatorPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.send),
              title: Text('Submit'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SubmitPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.message),
              title: Text('Message'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MessagePage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text('Name'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => NamePage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.account_circle),
              title: Text('User Info'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserFormPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.vaccines),
              title: Text('Marks Grading'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MarksFormScreen ()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.vaccines),
              title: Text('Marks lists'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MarksListScreen ()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.visibility),
              title: Text('User Display'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserDisplayPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.note),
              title: Text('New Page'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => NewPage()),
                );
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Text(
                      'BABA GURU NANAK UNIVERSITY',
                      style: TextStyle(
                        fontSize: 27,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 30),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Image.asset(
                        'assets/pic.jpg',
                        height: 200,
                        width: 600,
                        fit: BoxFit.cover,
                      ),
                    ),
                    SizedBox(height: 10),
                    Card(
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "About Baba Guru Nanak University",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.lightBlue,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              "Baba Guru Nanak University (BGNU) is a prestigious public-sector university located in Nankana Sahib, Punjab, Pakistan. "
                                  "The university is designed to accommodate 10,000 to 15,000 students worldwide and aims to provide quality education in multiple disciplines.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: 10),
                            Text(
                                  "BGNU offers a wide range of programs, including Medicine, Pharmacy, Engineering, Computer Science, Languages, and Social Sciences. "
                                      "An initial budget of PKR 6 billion has been allocated for development in three phases.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: 10),
                            Text(
                              "The university has signed MOUs with Govt. Guru Nanak (Post Graduate) College and Govt. Guru Nanak Associate College for Women "
                                  "for technical assistance and temporary classrooms until the academic buildings are completed.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: 10),
                            Text(
                              "The foundation stone was laid on October 28, 2019, by the Prime Minister of Pakistan. The Punjab Government passed the BGNU Act in 2020, "
                                  "ensuring the university meets global educational standards.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: 10),
                            Text(
                              "For Fall 2024, admissions will open soon with a range of academic programs. The university has also established a Centre of Excellence "
                                  "for Baba Guru Nanak & Sikh Cultural Heritage and a dedicated Chair for Punjab Studies.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(16.0),
            color: Colors.lightBlue,
            child: Center(
              child: Text(
                '© 2025 Baba Guru Nanak University | All Rights Reserved',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
