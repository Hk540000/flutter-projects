import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class GradeEntryPage extends StatefulWidget {
  @override
  _GradeEntryPageState createState() => _GradeEntryPageState();
}

class _GradeEntryPageState extends State<GradeEntryPage> {
  final TextEditingController courseController = TextEditingController();
  final TextEditingController subjectController = TextEditingController();
  final TextEditingController marksController = TextEditingController();
  final TextEditingController creditController = TextEditingController();

  Box get gradesBox => Hive.box('gradesBox');

  void saveLocally() {
    final data = {
      'course_name': courseController.text,
      'subject_name': subjectController.text,
      'marks': int.tryParse(marksController.text) ?? 0,
      'credit_hours': double.tryParse(creditController.text) ?? 0.0,
    };
    gradesBox.add(data);
    setState(() {
      courseController.clear();
      subjectController.clear();
      marksController.clear();
      creditController.clear();
    });
  }

  Future<void> uploadData() async {
    final List allGrades = gradesBox.values.toList();
    for (var grade in allGrades) {
      final response = await http.post(
        Uri.parse('https://hashamkhalid.pythonanywhere.com/api/grades/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(grade),
      );
      if (response.statusCode == 201) {
        print("Uploaded: $grade");
      } else {
        print("Failed to upload: ${response.body}");
      }
    }
    gradesBox.clear();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF7F8FC),
      appBar: AppBar(
        title: Text('Grade Entry', style: TextStyle(color: Colors.white)),
        backgroundColor: Color(0xFF5A55CA),
        centerTitle: true,
        elevation: 3,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            buildTextField(courseController, 'Course Name', Icons.school),
            SizedBox(height: 15),
            buildTextField(subjectController, 'Subject Name', Icons.book),
            SizedBox(height: 15),
            buildTextField(marksController, 'Marks', Icons.score, TextInputType.number),
            SizedBox(height: 15),
            buildTextField(creditController, 'Credit Hours', Icons.timelapse, TextInputType.number),
            SizedBox(height: 25),
            ElevatedButton.icon(
              icon: Icon(Icons.save, color: Colors.white),
              label: Text('Save Locally'),
              onPressed: saveLocally,
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF6C63FF),
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                textStyle: TextStyle(fontSize: 16),
              ),
            ),
            SizedBox(height: 30),
            Text(
              'Saved Entries',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.grey[800]),
            ),
            SizedBox(height: 10),
            buildDataTable(),
            SizedBox(height: 30),
            ElevatedButton.icon(
              icon: Icon(Icons.cloud_upload, color: Colors.white),
              label: Text('Upload Data'),
              onPressed: uploadData,
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF00B4D8),
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                textStyle: TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildTextField(
      TextEditingController controller, String label, IconData icon,
      [TextInputType keyboardType = TextInputType.text]) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Color(0xFF6C63FF)),
        filled: true,
        fillColor: Colors.white,
        contentPadding: EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget buildDataTable() {
    final items = gradesBox.values.toList();
    if (items.isEmpty) return Text("No local data found.", style: TextStyle(color: Colors.grey));

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        columnSpacing: 24,
        headingRowColor: MaterialStateProperty.all(Color(0xFFEEEEEE)),
        columns: const [
          DataColumn(label: Text('Course')),
          DataColumn(label: Text('Subject')),
          DataColumn(label: Text('Marks')),
          DataColumn(label: Text('Credits')),
        ],
        rows: items.map((item) {
          return DataRow(cells: [
            DataCell(Text(item['course_name'])),
            DataCell(Text(item['subject_name'])),
            DataCell(Text(item['marks'].toString())),
            DataCell(Text(item['credit_hours'].toString())),
          ]);
        }).toList(),
      ),
    );
  }
}
