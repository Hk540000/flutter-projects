import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({Key? key}) : super(key: key);

  // Fetch history from Firestore with document ID
  Stream<List<Map<String, dynamic>>> _getHistory() {
    return FirebaseFirestore.instance
        .collection('scanned_codes')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => {
      'id': doc.id, // Include document ID
      'data': doc['data'],
      'code_type': doc['code_type'],
      'timestamp': doc['timestamp'],
    })
        .toList());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan History'),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _getHistory(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No history found'));
          }

          final history = snapshot.data!;

          return ListView.builder(
            itemCount: history.length,
            itemBuilder: (context, index) {
              final entry = history[index];
              final docId = entry['id']; // Get document ID
              final data = entry['data'];
              final codeType = entry['code_type'];
              final timestamp = (entry['timestamp'] as Timestamp).toDate();

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: ListTile(
                  title: Text(data),
                  subtitle: Text('Type: $codeType\nDate: ${timestamp.toLocal()}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () async {
                      // Delete document using document ID
                      await FirebaseFirestore.instance
                          .collection('scanned_codes')
                          .doc(docId)
                          .delete();
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
