import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For Clipboard
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ScanFromCameraScreen extends StatefulWidget {
  const ScanFromCameraScreen({Key? key}) : super(key: key);

  @override
  _ScanFromCameraScreenState createState() => _ScanFromCameraScreenState();
}

class _ScanFromCameraScreenState extends State<ScanFromCameraScreen> {
  final MobileScannerController _controller = MobileScannerController();
  String scannedData = ''; // To hold scanned data
  bool hasScanned = false;

  // Method to save scanned data to Firestore
  void saveScannedData(String codeData, String codeType) {
    FirebaseFirestore.instance.collection('scanned_codes').add({
      'data': codeData,
      'code_type': codeType,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan QR/Bar Code from Camera'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Camera Preview
          SizedBox(
            height: 300,
            child: MobileScanner(
              controller: _controller,
              onDetect: (capture) {
                if (!hasScanned) {
                  final barcode = capture.barcodes.first;
                  final String code = barcode.rawValue ?? 'Unknown';

                  setState(() {
                    scannedData = code;
                    hasScanned = true;
                  });

                  saveScannedData(code, barcode.format.toString());

                  // Optionally stop camera after one scan
                  _controller.stop();
                }
              },
            ),
          ),
          const SizedBox(height: 20),

          // Display scanned data
          Text(
            scannedData.isEmpty ? 'Scan a QR/Bar Code' : 'Scanned Data: $scannedData',
            style: const TextStyle(fontSize: 18),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),

          // Button to copy the scanned data
          if (scannedData.isNotEmpty)
            ElevatedButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: scannedData));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Data copied to clipboard!')),
                );
              },
              child: const Text('Copy Data'),
            ),
        ],
      ),
    );
  }
}
