import 'package:flutter/material.dart';
import 'generate_qr_barcode_screen.dart';
import 'read_from_image_screen.dart';
import 'scan_from_camera_screen.dart';
import 'history_screen.dart';
import 'data_entry.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<_HomeCardItem> cardItems = [
      _HomeCardItem(
        label: 'Generate QR/Bar Code',
        icon: Icons.qr_code,
        destination: const GenerateQRCodeScreen(),
      ),
      _HomeCardItem(
        label: 'Choose from Gallery',
        icon: Icons.image,
        destination: const ReadFromImageScreen(),
      ),
      _HomeCardItem(
        label: 'Scan from Camera',
        icon: Icons.camera_alt,
        destination: const ScanFromCameraScreen(),
      ),
      _HomeCardItem(
        label: 'History',
        icon: Icons.history,
        destination: const HistoryScreen(),
      ),
      _HomeCardItem(
        label: 'Data Entry Form',
        icon: Icons.input,
        destination: FirebaseFormScreen(),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        backgroundColor: Colors.blueAccent,
        elevation: 0,
      ),
      body: Column(
        children: [
          const SizedBox(height: 30),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Welcome to the QR & Barcode App!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.blueAccent,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: GridView.count(
              padding: const EdgeInsets.all(16),
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              children: cardItems.map((item) {
                return _AnimatedHomeCard(item: item);
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeCardItem {
  final String label;
  final IconData icon;
  final Widget destination;

  _HomeCardItem({
    required this.label,
    required this.icon,
    required this.destination,
  });
}

class _AnimatedHomeCard extends StatefulWidget {
  final _HomeCardItem item;

  const _AnimatedHomeCard({Key? key, required this.item}) : super(key: key);

  @override
  State<_AnimatedHomeCard> createState() => _AnimatedHomeCardState();
}

class _AnimatedHomeCardState extends State<_AnimatedHomeCard>
    with SingleTickerProviderStateMixin {
  double _scale = 1.0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _animateCard(0.95),
      onTapUp: (_) {
        _animateCard(1.0);
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => widget.item.destination),
        );
      },
      onTapCancel: () => _animateCard(1.0),
      child: AnimatedScale(
        scale: _scale,
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeInOut,
        child: Card(
          elevation: 8,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          color: Colors.white,
          shadowColor: Colors.blueAccent.withAlpha(77),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(widget.item.icon, size: 48, color: Colors.blueAccent),
                const SizedBox(height: 10),
                Text(
                  widget.item.label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _animateCard(double scale) {
    setState(() {
      _scale = scale;
    });
  }
}
