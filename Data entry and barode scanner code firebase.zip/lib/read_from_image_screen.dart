import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';

class ReadFromImageScreen extends StatefulWidget {
  const ReadFromImageScreen({Key? key}) : super(key: key);

  @override
  _ReadFromImageScreenState createState() => _ReadFromImageScreenState();
}

class _ReadFromImageScreenState extends State<ReadFromImageScreen> {
  File? _image;
  String scannedData = '';
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
        scannedData = '';
      });
      _scanImage(_image!);
    }
  }

  Future<void> _scanImage(File imageFile) async {
    final inputImage = InputImage.fromFile(imageFile);
    final barcodeScanner = BarcodeScanner();

    try {
      final List<Barcode> barcodes = await barcodeScanner.processImage(inputImage);
      if (barcodes.isNotEmpty) {
        final result = barcodes.first.rawValue ?? 'No data found';
        setState(() {
          scannedData = result;
        });
        saveScannedData(result, barcodes.first.format.name);
      } else {
        setState(() {
          scannedData = 'No QR/Bar Code detected in the image';
        });
      }
    } catch (e) {
      setState(() {
        scannedData = 'Error: ${e.toString()}';
      });
    } finally {
      barcodeScanner.close();
    }
  }

  void saveScannedData(String codeData, String codeType) {
    FirebaseFirestore.instance.collection('scanned_codes').add({
      'data': codeData,
      'code_type': codeType,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Code from Image'),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 30.0),
        child: Column(
          children: [
            const Text(
              "Upload an Image to Scan QR/Bar Code",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _pickImage,
              icon: const Icon(Icons.image_search),
              label: const Text('Pick Image from Gallery'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                backgroundColor: Colors.deepPurple,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 30),
            if (_image != null)
              Card(
                elevation: 5,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(
                      _image!,
                      height: 200,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 20),
            if (scannedData.isNotEmpty)
              Card(
                color: Colors.grey[100],
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      const Text(
                        'Scanned Data',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.deepPurple,
                        ),
                      ),
                      const SizedBox(height: 10),
                      SelectableText(
                        scannedData,
                        style: const TextStyle(fontSize: 16),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 10),
                      ElevatedButton.icon(
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: scannedData));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Data copied to clipboard!')),
                          );
                        },
                        icon: const Icon(Icons.copy),
                        label: const Text('Copy Data'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepPurple,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
