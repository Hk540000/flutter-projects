import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:barcode_widget/barcode_widget.dart';

class GenerateQRCodeScreen extends StatefulWidget {
  const GenerateQRCodeScreen({Key? key}) : super(key: key);

  @override
  _GenerateQRCodeScreenState createState() => _GenerateQRCodeScreenState();
}

class _GenerateQRCodeScreenState extends State<GenerateQRCodeScreen> {
  final TextEditingController _controller = TextEditingController();
  bool isQRCode = true;

  @override
  void initState() {
    super.initState();
    _controller.addListener(() {
      setState(() {}); // Update display when input changes
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final inputData = _controller.text.trim().isEmpty
        ? 'Enter some text'
        : _controller.text.trim();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Generate QR / Bar Code'),
        backgroundColor: Colors.blueAccent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 30),
        child: Column(
          children: [
            const Text(
              "Create your QR or Bar Code",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: "Enter Text, URL or Number",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.text_fields),
              ),
            ),
            const SizedBox(height: 20),
            ToggleButtons(
              isSelected: [isQRCode, !isQRCode],
              onPressed: (int index) {
                setState(() {
                  isQRCode = index == 0;
                });
              },
              borderRadius: BorderRadius.circular(10),
              selectedColor: Colors.white,
              fillColor: Colors.blueAccent,
              children: const [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Text('QR Code'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Text('Bar Code'),
                ),
              ],
            ),
            const SizedBox(height: 30),
            Card(
              elevation: 5,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      isQRCode ? 'QR Code Preview' : 'Bar Code Preview',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent,
                      ),
                    ),
                    const SizedBox(height: 20),
                    if (isQRCode)
                      QrImageView(
                        data: inputData,
                        version: QrVersions.auto,
                        size: 200,
                        backgroundColor: Colors.white,
                      )
                    else
                      BarcodeWidget(
                        barcode: Barcode.code128(),
                        data: inputData,
                        width: 200,
                        height: 80,
                        drawText: true,
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
