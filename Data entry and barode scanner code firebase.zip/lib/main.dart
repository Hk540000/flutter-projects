import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'home_screen.dart'; // Assuming HomeScreen is defined in home_screen.dart

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR & Barcode App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blueAccent, // Accent color for the app
        brightness: Brightness.light,
        scaffoldBackgroundColor: Colors.grey[100], // Light background for the app
        textTheme: const TextTheme(
          bodyLarge: TextStyle(fontSize: 16, color: Colors.black87), // Updated to bodyLarge for Material 3
        ),
        appBarTheme: AppBarTheme(
          centerTitle: true,
          elevation: 5,
          backgroundColor: Colors.deepPurple, // Sleek dark purple app bar
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)), // Rounded app bar
          ),
          titleTextStyle: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        buttonTheme: ButtonThemeData(
          buttonColor: Colors.deepPurpleAccent,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
